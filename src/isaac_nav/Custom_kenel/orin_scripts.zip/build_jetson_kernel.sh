#!/usr/bin/env bash
# -----------------------------------------------------------------------------
#  * Detects the actual kernel tree directory (kernel‑jammy‑src / kernel‑5.*)
#  * Picks tegra_defconfig **if it exists**, else falls back to defconfig.
#  * Can resume at any stage with --from <step> (download | sync | config | build | initrd)
# -----------------------------------------------------------------------------
JETPACK_TAG="jetson_36.4.3"
INSTALL_PATH="$HOME/jetson_kernel_orin"
TOOLCHAIN_DIR="$HOME/l4t-gcc/aarch64--glibc--stable-2022.08-1"
CONFIG_FILE=""
PARALLEL="$(nproc)"
MENUCONFIG="1"

BASE_URL="https://developer.nvidia.com/downloads/embedded/l4t/r36_release_v4.3/release"
BSP_TARBALL="Jetson_Linux_r36.4.3_aarch64.tbz2"
ROOTFS_TARBALL="Tegra_Linux_Sample-Root-Filesystem_R36.4.3_aarch64.tbz2"
BSP_URL="${BASE_URL}/${BSP_TARBALL}"
ROOTFS_URL="${BASE_URL}/${ROOTFS_TARBALL}"

set -euo pipefail
export ARCH=arm64
export CROSS_COMPILE="${TOOLCHAIN_DIR}/bin/aarch64-buildroot-linux-gnu-"

log(){ echo -e "\e[32m[+] $*\e[0m"; }
err(){ echo -e "\e[31m[!] $*\e[0m" >&2; exit 1; }

# ------------------------------------------------ CLI -------------------------
START_FROM="download"  # default: run everything
usage() {
  cat <<EOF
Usage: $0 [options]
  -t <tag>            Jetson release tag (default: $JETPACK_TAG)
  -d <dir>            Workspace directory (default: $INSTALL_PATH)
  -c <config>         Use existing .config instead of defconfig(s)
  -j <jobs>           make -j parallelism (default: $(nproc))
  --no-menuconfig     Skip interactive menuconfig step
  --from <step>       Resume from: download | sync | config | build | initrd
  -h                  Show this help
EOF
}
parse_cli(){
  while [[ $# -gt 0 ]]; do
    case $1 in
      -t) JETPACK_TAG=$2; shift 2;;
      -d) INSTALL_PATH=$2; shift 2;;
      -c) CONFIG_FILE=$2; shift 2;;
      -j) PARALLEL=$2; shift 2;;
      --no-menuconfig) MENUCONFIG="0"; shift;;
      --from) START_FROM=$2; shift 2;;
      -h|--help) usage; exit 0;;
      *) err "Unknown option $1";;
    esac
  done
}

# -------------------- helpers -----------------------------
install_prereqs(){
  log "Installing host prerequisites …"
  sudo apt update
  sudo apt install -y git-core build-essential bc wget \
  bison flex libncurses5-dev libncursesw5-dev \
  gcc-aarch64-linux-gnu libssl-dev libelf-dev pkg-config dwarves qemu-user-static
}

download_toolchain(){
  if [[ ! -x "${CROSS_COMPILE}gcc" ]]; then
    log "Bootlin toolchain not found → downloading …"
    mkdir -p "$HOME/l4t-gcc" && cd "$HOME/l4t-gcc"
    wget -c https://toolchains.bootlin.com/downloads/releases/toolchains/aarch64/tarballs/aarch64--glibc--stable-2022.08-1.tar.bz2
    tar -xf aarch64--glibc--stable-2022.08-1.tar.bz2
  fi
}

download_bsp(){
  log "Preparing BSP & rootfs …"
  mkdir -p "$INSTALL_PATH" && cd "$INSTALL_PATH"
  [[ -f $BSP_TARBALL ]] || { log "Downloading $BSP_TARBALL"; wget -c "$BSP_URL"; }
  [[ -d Linux_for_Tegra ]] || tar -xf "$BSP_TARBALL"
  [[ -f $ROOTFS_TARBALL ]] || { log "Downloading $ROOTFS_TARBALL"; wget -c "$ROOTFS_URL"; }
  [[ -d Linux_for_Tegra/rootfs/etc ]] || sudo tar -xf "$ROOTFS_TARBALL" -C Linux_for_Tegra/rootfs/
}

sync_sources(){
  log "Syncing kernel sources (tag: $JETPACK_TAG) …"
  cd "$INSTALL_PATH/Linux_for_Tegra/source"
  [[ -x source_sync.sh ]] || { wget -q https://nv-tegra.nvidia.com/gitweb/?p=integrator/jetson-kernel-scripts.git;a=blob_plain;f=source_sync.sh -O source_sync.sh; chmod +x source_sync.sh; }
  ./source_sync.sh -k "$JETPACK_TAG"
}

# Detect kernel source directory (kernel-*, kernel-jammy-src, plain kernel)
detect_kernel_src(){
  local base="$INSTALL_PATH/Linux_for_Tegra/source/kernel"
  if compgen -G "$base/kernel-*" > /dev/null; then
     echo "$(ls -d $base/kernel-* | head -n1)"  # first matching dir
  else
     echo "$base"  # fall back
  fi
}

configure_kernel(){
  local KERNEL_SRC="$(detect_kernel_src)"
  local BUILD_DIR="$INSTALL_PATH/build_orin"
  mkdir -p "$BUILD_DIR"
  cd "$KERNEL_SRC"
  if [[ -n "$CONFIG_FILE" ]]; then
    log "Using provided .config: $CONFIG_FILE"
    cp "$CONFIG_FILE" "$BUILD_DIR/.config"
    make O="$BUILD_DIR" olddefconfig
  else
    local DEFAULT_CFG
    if [[ -f arch/arm64/configs/tegra_defconfig ]]; then
       DEFAULT_CFG=tegra_defconfig
    else
       DEFAULT_CFG=defconfig
    fi
    log "Using $DEFAULT_CFG as baseline …"
    make O="$BUILD_DIR" "$DEFAULT_CFG"
  fi
  [[ "$MENUCONFIG" == "1" ]] && make O="$BUILD_DIR" menuconfig
}

build_kernel(){
  local KERNEL_SRC="$(detect_kernel_src)"
  local BUILD_DIR="$INSTALL_PATH/build_orin"
  log "Compiling kernel …"
  make -C "$KERNEL_SRC" O="$BUILD_DIR" -j"$PARALLEL"
  make -C "$KERNEL_SRC" O="$BUILD_DIR" modules -j"$PARALLEL"
  log "Installing modules into rootfs …"
  sudo make -C "$KERNEL_SRC" O="$BUILD_DIR" INSTALL_MOD_PATH="$INSTALL_PATH/Linux_for_Tegra/rootfs" modules_install
  log "Copying Image & DTBs …"
  cp "$BUILD_DIR/arch/arm64/boot/Image" "$INSTALL_PATH/Linux_for_Tegra/kernel/Image"
  mkdir -p "$INSTALL_PATH/Linux_for_Tegra/kernel/dtb"
  find "$BUILD_DIR/arch/arm64/boot/dts" -name '*.dtb' -exec cp {} "$INSTALL_PATH/Linux_for_Tegra/kernel/dtb/" \;
}

update_initrd(){
  log "Updating initramfs …"
  cd "$INSTALL_PATH/Linux_for_Tegra"
  sudo ./tools/l4t_update_initrd.sh
}

# -------------------- pipeline orchestrator ----------------------
run_pipeline(){
  case $START_FROM in
    download) download_bsp; sync_sources; configure_kernel; build_kernel; update_initrd ;;
    sync)     sync_sources; configure_kernel; build_kernel; update_initrd ;;
    config)   configure_kernel; build_kernel; update_initrd ;;
    build)    build_kernel; update_initrd ;;
    # if you get some error related to not having some NVIDIA file after building, you need to run apply_binaries.sh script. 
    # cd Linux_for_Tegra/
    # sudo ./apply_binaries.sh

    initrd)   update_initrd ;;
    *) err "Unknown step $START_FROM" ;;
  esac
}
# ---------------- main ----------------
parse_cli "$@"
install_prereqs
download_toolchain
run_pipeline

log "\n✓ Kernel build stage '${START_FROM}' complete."
[[ "$START_FROM" != "initrd" ]] || log "Flash later with: cd $INSTALL_PATH/Linux_for_Tegra && sudo ./flash.sh --no-flash jetson-agx-orin-devkit mmcblk0p1"

# cd ~/jetson_kernel_orin/Linux_for_Tegra
# sudo ./tools/l4t_create_default_user.sh --accept-license -u robot_2 -p robomaster -a -n ep02
# sudo ./flash.sh jetson-agx-orin-devkit mmcblk0p1